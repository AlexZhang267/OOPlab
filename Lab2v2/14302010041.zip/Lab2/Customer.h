//
// Created by alex on 16-4-15.
//
#include "FamilyMart.h"
#ifndef LAB2_CUSTOMER_H
#define LAB2_CUSTOMER_H

class Customer{
public:
    static void purchase(FamilyMart &familyMart);
};

#endif //LAB2_CUSTOMER_H
