﻿# README
### 使用说明
1. 本次所提交代码全部在ubuntu14 + vim 环境下完成    
2. 使用时运行以下两行命令即可
+  g++ -o run run.cpp
+  ./run
3.  默认读取“sample.in”中的数据，并将计算结果输出至“result.txt”
4.  为了检测代码正确性，我在"sample.in"中另外添加了几行测试用例


