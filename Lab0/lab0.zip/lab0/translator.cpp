#include <iostream>

using namespace std;

int main() {
    // Your code here
    cout << "Hello, World!" << endl;
    return 0;
}